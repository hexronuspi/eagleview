import matplotlib
import pandas
from packaging import version

def test_matplotlib_version():
    # Check if the installed matplotlib version is compatible
    assert version.parse(matplotlib.__version__) >= version.parse("3.5.3"), "Requires matplotlib >= 3.5.3"

def test_pandas_version():
    # Check if the installed pandas version is compatible
    assert version.parse(pandas.__version__) >= version.parse("1.1.0"), "Requires pandas >= 1.1.0"

def test_pillow_version():
    try:
        import PIL
        # Check if the installed Pillow version is compatible
        assert version.parse(PIL.__version__) >= version.parse("8.0.0"), "Requires Pillow >= 8.0.0"
    except ImportError:
        assert False, "Pillow is not installed"