import sys
import pytest
from packaging import version
import matplotlib
import pandas
import PIL

# def test_python_version():
#     # Check if the Python version is supported
#     supported_versions = [(3, 6), (3, 7), (3, 8), (3, 9)]
#     assert sys.version_info[:2] in supported_versions, f"Unsupported Python version: {sys.version_info}"

def test_matplotlib_version():
    # Check if the installed matplotlib version is compatible
    assert version.parse(matplotlib.__version__) >= version.parse("3.0.0"), "Requires matplotlib >= 3.0.0"

def test_pandas_version():
    # Check if the installed pandas version is compatible
    assert version.parse(pandas.__version__) >= version.parse("1.0.0"), "Requires pandas >= 1.0.0"

def test_pillow_version():
    # Check if the installed Pillow version is compatible
    assert version.parse(PIL.__version__) >= version.parse("8.0.0"), "Requires Pillow >= 8.0.0"
